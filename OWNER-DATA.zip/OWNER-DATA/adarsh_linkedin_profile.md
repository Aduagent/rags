# Adarsh Kumar — LinkedIn Profile Data (Extracted)

## Basic Info
| Field | Value |
|---|---|
| **Name** | Adarsh Kumar |
| **Pronouns** | He/Him |
| **Headline** | Student at Dyal Singh College |
| **Location** | Delhi, India |
| **Profile URL** | www.linkedin.com/in/adarshu07 |
| **Profile Language** | English |
| **Account** | Free (LinkedIn Premium not active) |

## Network
- **48** connections
- **49** followers
- **16** unread notifications at time of capture

## Open to Work
- Visible to: **Everyone on LinkedIn** (public #OpenToWork badge)
- Location: Delhi, India
- Preferred work modes: **On-site · Hybrid**

## Experience
| Title | Type | Duration |
|---|---|---|
| **Developer** | Freelance (self-employed) | Jan 2024 – Present (2 yrs 10 mos) |

## Education
| Institution | Degree | Field | Tenure |
|---|---|---|---|
| **Dyal Singh College** | Bachelor of Commerce (B.Com) | Computer Science | Aug 2025 – Present |

## Services Offered (7 listed)
1. Web Development
2. Accounting
3. Editing
4. Video Editing
5. Training
6. Technical Support
7. Research Skills

## Interests (Companies followed)
- **GitHub** (6.7M followers)
- **Microsoft** (29M followers)

## Activity
- **No posts yet** — activity section is empty
- "You haven't posted yet"

## Analytics (Past 7 days)
| Metric | Count |
|---|---|
| Profile views | **6** |
| Search appearances | **14** |
| Post impressions | **0** |

## Profile Completeness — What's Missing / Suggested by LinkedIn
- ❌ No profile photo (a photo = up to 2.3× more profile views)
- ❌ No About/summary section (a summary = up to 3.9× more profile views)
- ❌ No posts
- No listed: Projects, Certifications, Licenses, Skills endorsements, or Recommendations

## Connection Context
- A connection named **Rishubh** (follows freeCodeCamp & Google Cloud pages)

---
*Extracted from saved LinkedIn HTML page, Oct 2026.*

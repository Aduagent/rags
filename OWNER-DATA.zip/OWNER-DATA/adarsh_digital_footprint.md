# 🕵️ ADARSH KUMAR — Complete Digital Footprint Deep Analysis
*Full audit across all platforms · Compiled Oct 6, 2026*

---

## 👤 IDENTITY CORE (assembled from cross-platform data)

| Field | Data | Source |
|---|---|---|
| **Full name** | Adarsh Kumar — likely **Adarsh Kumar ████████** | LinkedIn + HuggingFace-linked GitHub |
| **Nicknames** | आदर्शु (Aadarshu) · "शेखर उर्फ आदर्शु" (Shekhar aka Aadarshu) | YouTube channel title |
| **Email** | adarshukumar@gmail.com | GitHub README (public!) |
| **Location** | Delhi, India | LinkedIn |
| **Education** | B.Com (Computer Science), Dyal Singh College, University of Delhi — Aug 2025 → present | LinkedIn |
| **Age signal** | "07" appears in handles (adarshu07, Adarshukumar07) — likely birth year 2007 or lucky number | pattern |
| **Self-branding** | "AI Developer & ML Engineer" · "Coding Something Special" | GitHub |
| **Photo** | HuggingFace = anime-art avatar 🎨 · LinkedIn = NO photo · GitHub = default | — |

---

## 🗺️ THE FULL ACCOUNT MATRIX

### ✅ ALIVE & ACTIVE (5)

| # | Platform | Handle | ID/UIN | Findings |
|---|---|---|---|---|
| 1 | **GitHub** | @Adarshukumar | UID **268533455** | 16 public repos · committed **8 hrs** before audit · fire README · 1 follower / 2 following · bio "Adarsh Ltd....." |
| 2 | **HuggingFace** | @AdarshJi | UID **65bb2911145d4d463b7d162f** | **16 Spaces** · 3 likes · anime avatar · links to dead GitHub #2 |
| 3 | **LinkedIn** | /in/adarshu07 | — | 48 connections · 49 followers · 0 posts · no photo · no About · 7 services listed |
| 4 | **Linktree** | /adarshu | joined **Mar 2026** | 5 links (1 dead) · GIF avatar |
| 5 | **YouTube** | @Adarshukumar | — | Channel exists: "_____शेखर उर्फ आदर्शु 🖤😞" · **0 videos** |

### ☠️ DEAD / BROKEN (3) — *all publicly linked, all bad looks*

| # | Property | URL | Status |
|---|---|---|---|
| 6 | **Personal website** | sdk.adarshu.unaux.com | ❌ **DNS error — GONE.** It's your Insta/Linktree "Website" link!! Free iFastNet hosting expired |
| 7 | **GitHub #2** | @AdarshKumar████████ | ❌ **404 — deleted.** Still linked FROM your HuggingFace profile |
| 8 | **Itch.io** | adarshukumar.itch.io | ❌ **404.** Still linked from your GitHub README's social row |

### 🔒 EXISTS — BLOCKED TO SCRAPERS (5)

| # | Platform | Handle | Notes |
|---|---|---|---|
| 9 | **Instagram** | @adarshu.io | Hard 403 wall; not indexed by search engines either (very fresh or strict privacy) |
| 10 | **X (Twitter)** | @Adarshukumar07 | Scrapers blocked; handle confirmed via Linktree + README |
| 11 | **Spotify** | user/Adarshukumar | reCAPTCHA wall; linked from README |
| 12 | **Discord** | Adarshukumar | Linked from README; not scrapable by nature |

### ❌ NOT FOUND (you don't have these — verified 404)
LeetCode · Kaggle · CodeWars · dev.to · Medium · Stack Overflow

---

## 🧪 HuggingFace Spaces Breakdown (16) — what you're into

| Space | What it is |
|---|---|
| CSSSC 📈 · DDS 💻 · MD 🔥 · IMGDEPLOY 🔥 | Unnamed/utility deploys |
| **FLOWER 📈** | Bing search API proxy |
| **api-gg 🚀 · TTS 📚** | Text-to-Speech APIs |
| **api 🌍 · IMAGE-GEN 👁 · Generation 📈** | Text→image generation APIs |
| **strangerzonehf Flux-Midjourney-Mix2-LoRA 🏆** | Dupe of a Flux LoRA image model |
| **FALTU_ADARSH 🚀** | "High-speed chat traffic proxy" 💀 |
| **n8n ⚡** | Workflow automation hosting |
| **Deepifra 👀 · DPSERC 🏆 · SANGCHI 🏆** | Unknown/private utility |

**Pattern spotted:** you're into **free-API infrastructure** — hosting image-gen / TTS / search APIs and proxies on HF Spaces. Genuinely clever hustle, bro.

## 📦 GitHub Repos Breakdown (16)
`Python` (all Python projects, active 8h ago) · `linkedin` · `serv__` ("desking") · `aduskill` (MIT) · `skills` (MIT) · `public` ("beahhh") · `rags` (RAG?) · `Broken-apk` (C) · `apk` · `wtf` · `cloud` · `meow` ("Denchuuu") · **`Perc`** ⭐1 · `galleryserver-docker` (HF-compatible image API — README says "Can be NSFW" ⚠️) · `RepopoxRev` · `Adarshukumar` (profile README)

---

## 🔀 BRAND FRAGMENTATION AUDIT — you are 10 different people online 😅

```
Adarsh Kumar  →  Adarsh kumar  →  Adarsh Kumar ████████
AdarshJi  →  adarshu  →  Adarshukumar  →  adarshu07
adarshu.io  →  Adarshukumar07  →  शेखर उर्फ आदर्शु
```
**Cost:** Google "Adarsh Kumar" (your LinkedIn name) → none of your GitHub/HF assets rank. Your best work is invisible under aliases.

---

## 🧠 DEEP INSIGHTS (the real talk section)

1. **Your work is REAL** — daily commits, 16 deployed HF Spaces, workflow automation, API building. This isn't resume inflation; you actually build. ✅
2. **LinkedIn is the weakest platform while GitHub is the strongest** — exactly backwards from how recruiters search. Fix = port the GitHub energy into LinkedIn (makeover file's done for you).
3. **Two dead 404s are publicly linked** (AdarshKumar████████ from HuggingFace, Itch.io from GitHub README) + dead website in your bio hub. First impression = broken. Priority fix. 🔥
4. **The `galleryserver-docker` description ("Can be NSFW") + joke repos (`wtf`, `meow`, `beahhh`) + `FALTU_ADARSH`** are all one Google-click away from your professional profiles. Fun ≠ cheap — re-describe or privatize. ⚠️
5. **No presence on the skill-proof platforms** — LeetCode, Kaggle, CodeWars. Even a bare Kaggle account with 1 notebook strengthens the "ML Engineer" claim. Easy W.
6. **Your HF anime avatar is fire 🎨 but LinkedIn has no photo at all** — profiles with photos get 2.3× views; your face is the one platform-specific asset you're missing.
7. **Email exposure note:** adarshukumar@gmail.com is fully public in your GitHub README. That's fine for freelance leads — just be ready for spam and never reuse that email for sensitive signups.

---

## 🎯 PRIORITY FIX LIST (in order — do these exact steps)

**P0 — Stop the bleeding (15 min)**
- [ ] Remove dead website from Linktree (or point it to your GitHub for now)
- [ ] Remove AdarshKumar████████ link from HuggingFace profile
- [ ] Remove Itch.io icon from GitHub README
- [ ] Rewrite `galleryserver-docker` description → "HF-compatible image generation API server, Dockerized"

**P1 — Unify the brand (30 min)**
- [ ] Pick ONE handle family: **adarshu** (short, available on Linktree already) — use `adarshu`/`Adarshukumar` consistently
- [ ] Apply the LinkedIn makeover (file: `adarsh_linkedin_makeover.md`)
- [ ] Same photo/avatar style across LinkedIn + GitHub + HF

**P2 — Level up (this week)**
- [ ] Privatize `wtf`, `meow`, `beahhh`; write 3-line READMEs for `Perc`, `rags`, `aduskill`
- [ ] Create Kaggle account, post 1 notebook (your Python repo experiments → notebook)
- [ ] Post LinkedIn Post #1 (already written in the makeover file)

**P3 — The big one**
- [ ] Replace the dead website with a REAL portfolio → **I can build this for you right now** — dark theme, your HF spaces as live demos, GitHub projects, services, contact. Just say "build it" 🚀

---

*Sources: LinkedIn HTML export · linktr.ee/adarshu · github.com/Adarshukumar (+all 16 repos) · huggingface.co/AdarshJi (+16 spaces) · youtube.com/@Adarshukumar · itch.io · leetcode · kaggle · reddit · facebook · spotify · X · web searches. Blocked platforms noted as inaccessible.*
